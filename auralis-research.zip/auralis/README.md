# Auralis：基于 JEPA 的音乐世界模型

Auralis: A JEPA-Based World Model for Music

作者 / Author：赵伟峰（Weifeng Zhao）

Auralis 是一个个人研究项目，探索在音频音乐生成模型的内部表示上引入 JEPA，预测音乐片段之间的关系。该项目目前处于研究提案和代码原型阶段，模型尚未训练，没有权重或实验结果。

Auralis is a personal research project exploring JEPA over internal representations of audio music generation models. It is an untrained research proposal and prototype, with no released weights or experimental results.

## 项目内容 / Contents

- [中文版技术报告](report/technical-report-zh.md)
- [English technical report](report/technical-report-en.md)
- [代码与运行说明 / Code and usage](code/README.md)

代码接受外部预提取的一维音频 token，尚不包含实际音频 token 提取器、ACE-Step 接入、模型评估、歌曲生成或音频输出。两份报告中的架构图为设计提案，接口均需核实。建议数据集及其使用边界列于报告中。请分别核对代码、模型、数据及底层作品的许可。

The code accepts externally extracted one-dimensional audio tokens. It does not yet extract tokens from audio, connect to ACE-Step, evaluate the model, generate songs, or produce audio. The architecture is a proposal and its integration paths require verification.

项目名称 Auralis 已被其他音乐和音频项目使用，未完成全面同名或商标检索。 / Other music and audio projects already use the name Auralis; a comprehensive name and trademark check has not been completed.

## 许可 / License

本项目的原创技术报告、架构图和代码由赵伟峰（Weifeng Zhao）以 [CC BY-NC 4.0（署名—非商业性使用）](https://creativecommons.org/licenses/by-nc/4.0/deed.zh-hans) 许可发布。允许按协议进行非商业分享和改编，分享时须署名、注明修改并保留许可信息。商业使用请联系作者另行取得书面授权：149199879@qq.com。第三方代码、模型、数据及音乐作品遵循各自许可。

Copyright (c) 2026 Weifeng Zhao (赵伟峰). Original reports, architecture diagrams and code are licensed under [Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)](https://creativecommons.org/licenses/by-nc/4.0/). Noncommercial sharing and adaptation are permitted under the license, with attribution, indication of changes and retention of license information when sharing. For separate written commercial permission, contact 149199879@qq.com. Third-party code, models, datasets and musical works remain subject to their own terms.

完整协议见 [LICENSE](LICENSE)。
