# Auralis：基于 JEPA 的音乐世界模型

Auralis: A JEPA-Based World Model for Music

作者 / Author：赵伟峰（Weifeng Zhao）

Auralis 是一个个人研究项目，探索在音频音乐生成模型的内部表示上引入 JEPA，预测音乐片段之间的关系。该项目目前处于研究提案和代码原型阶段，模型尚未训练，没有权重或实验结果。

Auralis is a personal research project exploring JEPA over internal representations of audio music generation models. It is an untrained research proposal and prototype, with no released weights or experimental results.

## 项目内容 / Contents

- [中文版技术报告](report/technical-report-zh.md)
- [English technical report](report/technical-report-en.md)
- [代码与运行说明 / Code and usage](code/README.md)

代码接受外部预提取的一维音频 token，尚不包含实际音频 token 提取器、ACE-Step 接入、模型评估、歌曲生成或音频输出。两份报告中的架构图为设计提案，接口均需核实。建议数据集及其使用边界列于报告中。请分别核对代码、模型、数据及底层作品的许可。

The code accepts externally extracted one-dimensional audio tokens. It does not yet extract tokens from audio, connect to ACE-Step, evaluate the model, generate songs, or produce audio. The architecture is a proposal and its integration paths require verification.

项目名称 Auralis 已被其他音乐和音频项目使用，未完成全面同名或商标检索。 / Other music and audio projects already use the name Auralis; a comprehensive name and trademark check has not been completed.

## 许可 / License

本项目仅允许非商业研究与教育用途；商业使用须事先获得作者书面授权。详见 [LICENSE](LICENSE)，授权联系：149199879@qq.com。

Non-commercial research and educational use only; commercial use requires prior written permission. See [LICENSE](LICENSE). Contact: 149199879@qq.com.
