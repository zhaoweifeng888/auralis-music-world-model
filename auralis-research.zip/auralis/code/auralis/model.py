"""A small token-to-latent JEPA; independent of any specific audio tokenizer."""
import copy
import torch
from torch import nn
import torch.nn.functional as F


class TokenEncoder(nn.Module):
    def __init__(self, vocab_size, dimension, max_len):
        super().__init__()
        self.tokens = nn.Embedding(vocab_size, dimension)
        self.position = nn.Embedding(max_len, dimension)
        layer = nn.TransformerEncoderLayer(dimension, 4, dimension * 4,
                                           batch_first=True, dropout=0.0)
        self.encoder = nn.TransformerEncoder(layer, num_layers=2)
        self.norm = nn.LayerNorm(dimension)

    def forward(self, ids):
        positions = torch.arange(ids.shape[1], device=ids.device)
        x = self.tokens(ids) + self.position(positions)[None, :, :]
        return self.norm(self.encoder(x)).mean(dim=1)


class AuralisJEPA(nn.Module):
    def __init__(self, vocab_size, dimension=128, max_len=128, ema=0.99):
        super().__init__()
        self.online = TokenEncoder(vocab_size, dimension, max_len)
        self.target = copy.deepcopy(self.online)
        self.target.requires_grad_(False)
        self.predictor = nn.Sequential(nn.Linear(dimension, dimension * 2),
                                       nn.GELU(), nn.Linear(dimension * 2, dimension))
        self.ema = ema

    def forward(self, context, future):
        context_state = self.online(context)
        predicted = self.predictor(context_state)
        with torch.no_grad():
            target = self.target(future)
        prediction_loss = F.mse_loss(predicted, target)
        # Monitor/train both views to discourage collapsed output. This is not a guarantee.
        encoded = torch.cat((context_state, self.online(future)), dim=0)
        std = torch.sqrt(encoded.var(dim=0, unbiased=False) + 1e-4)
        variance_loss = F.relu(1.0 - std).mean()
        return prediction_loss, variance_loss, std.mean()

    @torch.no_grad()
    def update_target(self):
        for target, online in zip(self.target.parameters(), self.online.parameters()):
            target.mul_(self.ema).add_(online, alpha=1.0 - self.ema)
