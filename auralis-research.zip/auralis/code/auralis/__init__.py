"""Auralis latent prediction research prototype."""
