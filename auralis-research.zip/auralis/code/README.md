# Auralis training prototype

未训练的研究代码。该原型只接受已提取的一维整数 token，预测未来窗口的潜在向量；不包含 ACE-Step 连接、音频提取、候选排序、评测、解码或歌曲生成。token 并不天然对应音乐语义。随机 token 仅供程序检查，不能得到有效音乐模型。

## 安装与运行

Python 3.10+：

```bash
pip install -r requirements.txt
python train.py --synthetic --vocab-size 1024 --steps 2
python train.py --token-dir data/train --vocab-size 1024 --steps 100
```

实际 token 词表大小须按所用 tokenizer 确定；1024 仅为示例。预先准备每首作品一个 `.npz` 文件，包含名为 `tokens` 的一维整型数组，token ID 的范围为 `[0, vocab_size)`。例如：

```python
import numpy as np
np.savez_compressed('data/train/example.npz', tokens=np.array([0, 3, 2, 1], dtype=np.int64))
```

示例数组太短，不能用于默认长度训练。固定 tokenizer 版本、频率与词表，并按作品将训练与测试分开。此代码不包含自动划分或去重。默认 40/20 token 仅在 5 Hz 时分别相当于 8/4 秒；其他帧率须调整。程序目前均匀抽取作品与窗口，只保存最后权重，没有验证集或断点恢复功能。

## 实现状态

Transformer 编码器、固定长度上下文/未来窗口、EMA 目标、潜在均方误差和简易方差正则已编写；脚本尚未在 PyTorch 环境中运行验证。编码器目标与在线网络从同一初始化出发；方差正则和 EMA 不保证防止坍缩，指标和严格对照尚未实现。现实音频 tokenizer 的具体提取、词表和逆向生成均需单独验证，不保证可直接用于 ACE-Step。
