"""Baseline training on 1D integer audio tokens supplied as NPZ files."""
import argparse
import json
from pathlib import Path
import numpy as np
import torch
from auralis.model import AuralisJEPA


def load_sequences(directory, vocab_size):
    files = sorted(Path(directory).glob('*.npz'))
    if not files:
        raise ValueError(f'No .npz files found in {directory}')
    sequences = []
    for file in files:
        with np.load(file, allow_pickle=False) as data:
            a = data['tokens']
        if a.ndim != 1 or not np.issubdtype(a.dtype, np.integer):
            raise ValueError(f'{file}: tokens must be a one-dimensional integer array')
        if len(a) == 0 or a.min() < 0 or a.max() >= vocab_size:
            raise ValueError(f'{file}: token IDs must lie in [0, vocab_size)')
        sequences.append(a.astype(np.int64))
    return sequences


def main():
    p = argparse.ArgumentParser()
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument('--token-dir', help='Training split only; one NPZ file per piece')
    group.add_argument('--synthetic', action='store_true', help='Artificial IDs for smoke tests only')
    p.add_argument('--vocab-size', type=int, required=True)
    p.add_argument('--context-length', type=int, default=40)
    p.add_argument('--target-length', type=int, default=20)
    p.add_argument('--batch-size', type=int, default=16)
    p.add_argument('--steps', type=int, default=100)
    p.add_argument('--dimension', type=int, default=128)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--output', default='checkpoints/auralis.pt')
    args = p.parse_args()
    if min(args.vocab_size, args.context_length, args.target_length, args.steps) < 1 or args.batch_size < 2:
        p.error('Lengths, vocabulary and steps must be positive; batch size must be at least 2.')
    if args.dimension < 4 or args.dimension % 4:
        p.error('dimension must be a positive multiple of 4.')
    rng = np.random.default_rng(args.seed)
    torch.manual_seed(args.seed)
    window = args.context_length + args.target_length
    if args.synthetic:
        sequences = [rng.integers(0, args.vocab_size, size=window * 2, dtype=np.int64) for _ in range(32)]
    else:
        sequences = load_sequences(args.token_dir, args.vocab_size)
    sequences = [x for x in sequences if len(x) >= window]
    if not sequences:
        raise ValueError('No sequence is long enough for the requested context and target.')
    device = torch.device('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu')
    model = AuralisJEPA(args.vocab_size, args.dimension, max(args.context_length, args.target_length)).to(device)
    optimizer = torch.optim.AdamW(list(model.online.parameters()) + list(model.predictor.parameters()), lr=3e-4)
    print(json.dumps({'device': str(device), 'pieces': len(sequences), 'synthetic': args.synthetic}))
    for step in range(args.steps):
        examples = []
        for _ in range(args.batch_size):
            sequence = sequences[int(rng.integers(0, len(sequences)))]
            start = int(rng.integers(0, len(sequence) - window + 1))
            examples.append(sequence[start:start + window])
        batch = torch.from_numpy(np.stack(examples)).to(device)
        context = batch[:, :args.context_length]
        future = batch[:, args.context_length:]
        prediction, variance, std = model(context, future)
        loss = prediction + 0.1 * variance
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        model.update_target()
        if step == 0 or (step + 1) % 10 == 0 or step + 1 == args.steps:
            print(f'step={step + 1} pred={prediction.item():.5f} variance_loss={variance.item():.5f} mean_std={std.item():.5f}')
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    torch.save({'model': model.state_dict(), 'config': vars(args)}, out)
    print(f'Saved {out}. No musical performance has been validated.')


if __name__ == '__main__':
    main()
